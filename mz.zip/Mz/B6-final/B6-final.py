from gpiozero import *

PER=0

btn1=17
btn2=27

def smanji():
    global PER
    print('smannji')
    if PER >= 10:
        PER-=10

def uvecaj():
    global PER
    print('povecaj')
    if PER<=90:
        PER+=10
        
SMANJI=Button(btn1)
SMANJI.when_pressed=smanji

UVECAJ=Button(btn2)
UVECAJ.when_pressed=uvecaj

led1=18
led2=19
led3=20

LED_1=PWMLED(led1)
LED_2=PWMLED(led2)
LED_3=PWMLED(led3)

while True:
    LED_1.value=PER/100
    LED_2.value=PER/100
    LED_3.value=PER/100