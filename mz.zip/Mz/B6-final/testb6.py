from gpiozero import *
import time
r=LED(18)
y=LED(19)
g=LED(20)
uvecaj=Button(27)
smanji=Button(17)
while True:
    uvecaj.wait_for_press()
    time.sleep(.2)
    r.on()
    y.on()
    g.on()
    smanji.wait_for_press()
    time.sleep(.2)
    r.off()
    y.off()
    g.off()