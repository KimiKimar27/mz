from gpiozero import LED,Button
import time
import tm1637
tm=tm1637.TM1637(clk=3,dio=2)
crveno=LED(18)
zuto=LED(15)
zeleno=LED(14)
buton=Button(25)
number=0
temp=0
tm.number(number)
PS=1
SS=0
n=0
s=0
print('LJubica')
while 1==1:
    
    if buton.is_pressed:
        crveno.off()
        zuto.off()
        zeleno.off()
        time.sleep(1)
        while PS!=SS:
            if buton.is_pressed:
                SS=1
            n=0
            crveno.on()
            s=8
            for n in range(s):
                tm.number(s-n)
                n+=1
                time.sleep(1)
                
            if buton.is_pressed:
                SS=1    
            n=0
            zuto.on()
            s=2
            for n in range(s):
                tm.number(s-n)
                n+=1
                time.sleep(1)
            if buton.is_pressed:
                SS=1
            n=0
            crveno.off()
            zuto.off()
            zeleno.on()
            s=7
            for n in range(s):
                tm.number(s-n)
                n+=1
                time.sleep(1)
            if buton.is_pressed:
                SS=1
            n=0
            s=3
            for n in range(s):
                zeleno.off()
                time.sleep(0.5)
                tm.number(s-n)
                n+=1
                zeleno.on()
                time.sleep(0.5)
                
            if buton.is_pressed:
                SS=1
            n=0
            zeleno.off()
            zuto.on()
            s=2
            for n in range(s):
                tm.number(s-n)
                n+=1
                time.sleep(1)
            if buton.is_pressed:
                SS=1
            n=0
            zuto.off()
            
            
            
            
        
        if PS==SS:
            SS=0
            crveno.off()
            zuto.off()
            zeleno.off()
            print('YLA LJUBICA')
        time.sleep(2)