from gpiozero import *
import time
import tm1637
tm=tm1637.TM1637(clk=3,dio=2)
r=LED(18)
y=LED(15)
g=LED(14)
button=Button(25)
tm.show('    ')
state=False
while True:
    if button.is_pressed:
        state=not state
        time.sleep(0.5)
        print(state)
    if state==True:
        time.sleep(0.2)
        r.on()
        y.on()
        g.on()
        tm.number(88)
        time.sleep(.2)
        r.off()
        y.off()
        g.off()
        tm.show('    ')
