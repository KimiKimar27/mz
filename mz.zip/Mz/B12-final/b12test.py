from gpiozero import *
from rpi_lcd import LCD
import time
b=Button(16)
lcd=LCD()
lcd.text("Dobar dan",1)
b.wait_for_press()
time.sleep(.2)
lcd.text("Zdravo",1)
