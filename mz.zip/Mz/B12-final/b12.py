from gpiozero import *
import time
import random
from rpi_lcd import LCD
b=0
btn=Button(16)
lcd=LCD()
lcd.text("Dobro dosli",1)
time.sleep(3)
lcd.text("Baci kockicu",1)
state=0
while state==0:
    btn.wait_for_press()
    b=b+1
    lcd.clear()
    a=random.randint(1,6)
    lcd.text("Vas " + str(b) + " broj je " + str(a),1)
    if a==6:
        lcd.text("Baci ponovo",2)
    else:
        state=1
    time.sleep(0.5)