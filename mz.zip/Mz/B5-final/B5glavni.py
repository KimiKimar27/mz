from gpiozero import *
from time import sleep
import Adafruit_DHT as dht
from rpi_lcd import LCD


grejalica=LED(14)
hladnjak=LED(15)

lcd=LCD()
DHT=4

hladnjak.off()
grejalica.off()





referentna_temp=-1
procitana_temp=None
procitana_vlaz=None

print("Upisite referentnu temperaturu")
referentna_temp=int(input())

def procitaj():
    
    global referentna_temp
    global procitana_temp
    global procitana_vlaz

    while(procitana_vlaz is None or procitana_temp is None):
        procitana_vlaz, procitana_temp=dht.read(dht.DHT22, DHT)  

    
    lcd.text(f"Temp:{int(procitana_temp)}C{int(referentna_temp)}C",1)
    temp=(f"Vlaga:{int(procitana_vlaz)}%")
    
    hladnjak.off()
    grejalica.off()
    
    if procitana_temp>referentna_temp:
        temp+="HLA"
        hladnjak.on()
    elif procitana_temp<referentna_temp:
        temp+="GRE"
        grejalica.on()
    else:
        temp+="NIS"
    
    lcd.text(temp,2)
    sleep(2)
    
    print(" ",procitana_temp)
    procitana_temp=procitana_vlaz=None
    
while True:
    procitaj()
    