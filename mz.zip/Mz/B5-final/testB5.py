from rpi_lcd import LCD
import Adafruit_DHT as dht
from time import sleep
from gpiozero import *

r=LED(14)
g=LED(15)

lcd = LCD()
DHT = 4

lcd.text("test", 1)

while True:
    h,t = dht.read_retry(dht.DHT22, DHT)    
    print((t, h))
    sleep(0.5)
    r.on()
    g.off()
    sleep(0.5)
    r.off()
    g.on()


